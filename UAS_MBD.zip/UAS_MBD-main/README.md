# UAS_MBD_Shandy Ilham Alamsyah_21091397015_MI2021A
Migration & Seeding Database Laravel

1. Buat Migration File
![246091644-e5a22494-2c9f-4517-b394-aad0d6e06bbb](https://github.com/ShandyIlham/UAS_MBD/assets/89757776/0d74e0e4-430b-44da-8fac-a9e8e9956114)

2. Edit File Migration
![246092319-67a8784e-3729-408e-8578-125181a23cab](https://github.com/ShandyIlham/UAS_MBD/assets/89757776/282d424d-08ac-475f-9bdf-5bbd42be0547)

3. Migrate Database
![246090449-d675592a-04c9-4999-8994-b94cca511354](https://github.com/ShandyIlham/UAS_MBD/assets/89757776/d082344a-0b2a-4b31-8616-108fe44e87d0)

4. Buat Seeder File
![246091398-73e56aa4-1aaa-4bbc-86d3-6a58ef02f8a4](https://github.com/ShandyIlham/UAS_MBD/assets/89757776/b39d3b5e-9ec9-4284-be1d-26a66b236289)

5. Edit File Seeder
![246097552-e6a70631-612c-402d-9470-b6f0722831aa](https://github.com/ShandyIlham/UAS_MBD/assets/89757776/d6a30684-7979-43da-9440-98bb3596b163)

6. Seeder Isi Database
![246114126-b22c89d8-60f9-4c54-af85-af7f948ed322](https://github.com/ShandyIlham/UAS_MBD/assets/89757776/932efb6f-daed-4069-9788-dc337d445881)
